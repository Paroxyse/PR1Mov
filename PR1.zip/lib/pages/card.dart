import 'package:flutter/material.dart';

class Cards extends StatefulWidget
{
  @override 
  State<StatefulWidget> createState()
  {
   return CustomCard(); 
  }
}
  class CustomCard extends State<Cards>
  {
    @override
  Widget build(BuildContext context)
  {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10)
      ),
   elevation: 10,
   margin: EdgeInsets.all(10),
   child: new Column(
     children: [
       Text("bottom text"),
       Image.asset("assets/medium.png")],
   )
   //contenido :D 
    );
  }
  }
